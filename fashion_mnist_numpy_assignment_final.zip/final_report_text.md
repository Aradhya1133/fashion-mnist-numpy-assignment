# Fashion-MNIST Neural Network Assignment

## Question 1

The Fashion-MNIST dataset was loaded using keras.datasets.fashion_mnist.
One sample image from each of the 10 classes was plotted in a 2 x 5 grid.

## Question 2

A flexible feedforward neural network was implemented using NumPy.
Each image was flattened from 28 x 28 into a 784-dimensional vector.
The network supports different hidden layer sizes and different numbers of
hidden layers.

The output layer uses softmax, so the model produces a probability
distribution over 10 classes.

## Question 3

Backpropagation was implemented from scratch using NumPy.
The following optimizers were implemented:

- SGD
- Momentum
- Nesterov
- RMSProp
- Adam
- Nadam

All optimizers were tested using the same training framework.

## Question 4

W&B random sweep was used for hyperparameter tuning.
Random search was selected because the full grid search would take too much
time.

The sweep tested different values for epochs, hidden layers, hidden size,
weight decay, learning rate, optimizer, batch size, initialization, and
activation function.

## Question 5

Best validation accuracy from sweep:

0.88817

Best run:

hl_3_hs_64_bs_64_ac_tanh_opt_nadam

## Question 6

Main observations:

1. Adaptive optimizers performed better than plain SGD.
2. Xavier initialization was more stable than random initialization.
3. Very high weight decay reduced accuracy.
4. Tanh and ReLU performed better than weak sigmoid configurations.
5. Larger hidden layers usually worked better than very small hidden layers.

Recommended configuration:

- Hidden layers: 4
- Hidden size: 128
- Activation: tanh
- Optimizer: rmsprop
- Learning rate: 0.001
- Batch size: 64
- Weight initialization: xavier
- Weight decay: 0.0005

## Question 7

Final Fashion-MNIST test accuracy:

0.86340

Final Fashion-MNIST test loss:

0.46084

The confusion matrix shows that most predictions are on the diagonal.
The largest confusion is usually between visually similar classes such as
Shirt, T-shirt/top, Pullover, and Coat.

## Question 8

Cross-entropy loss and squared error loss were compared using the same model
configuration.

Cross-entropy is preferred because it is more suitable for multi-class
classification with softmax output.

Loss comparison table:

    loss_name  best_val_acc  test_acc  test_loss
cross_entropy      0.874167    0.8634   0.460843
squared_error      0.863667    0.8513   0.136149

## Question 9

GitHub repository link:

https://github.com/Aradhya1133/fashion-mnist-numpy-assignment.git

## Question 10

Three MNIST configurations were tested.

                            name optimizer activation  hidden_layers  hidden_size  batch_size  learning_rate  weight_decay weight_init  best_val_acc  test_acc  test_loss
mnist_cfg1_best_fashion_transfer   rmsprop       tanh              4          128          64          0.001        0.0005      xavier      0.966667    0.9715   0.184093
           mnist_cfg2_tanh_nadam     nadam       tanh              4          128          64          0.001        0.0005      xavier      0.971500    0.9733   0.168252
            mnist_cfg3_relu_adam      adam       relu              4          128          64          0.001        0.0005      xavier      0.975167    0.9761   0.153201

Based on the results, the best MNIST configuration by validation accuracy was:

mnist_cfg3_relu_adam

The best MNIST configuration by test accuracy was:

mnist_cfg3_relu_adam

The Fashion-MNIST learnings transferred well to MNIST because Xavier
initialization and adaptive optimizers also performed strongly on MNIST.