# Fashion-MNIST Neural Network from Scratch

This project implements a feedforward neural network from scratch
using NumPy for Fashion-MNIST classification.

## Features

- Fashion-MNIST loading and visualization
- Flexible feedforward neural network
- Backpropagation from scratch
- Mini-batch training
- Cross-entropy and squared-error loss
- SGD, Momentum, Nesterov, RMSProp, Adam, and Nadam optimizers
- W&B sweep support
- Final test evaluation
- Confusion matrix
- MNIST transfer experiments

## Setup

Install the required packages:

pip install numpy pandas matplotlib wandb keras

## Training

Run the notebook cells in order.

First log in to W&B:

wandb.login()

Then run the sweep cell to start hyperparameter search.

## Final Fashion-MNIST configuration

- Hidden layers: selected from W&B sweep
- Hidden size: selected from W&B sweep
- Activation: selected from W&B sweep
- Optimizer: selected from W&B sweep
- Learning rate: selected from W&B sweep
- Batch size: selected from W&B sweep
- Weight initialization: selected from W&B sweep
- Weight decay: selected from W&B sweep

## Test data rule

The test set is used only after selecting the best model using
validation accuracy. The test set is not used during training or
hyperparameter tuning.

## GitHub

Paste the GitHub repository link in the final assignment report.